<?php
/**
 * Plantilla general: Diario (blog), archivos, entradas y páginas.
 */
get_header();
?>
<main id="contenido" class="page-shell">
  <?php if ( is_singular() ) : ?>
    <?php while ( have_posts() ) : the_post(); ?>
      <article <?php post_class( 'entry' . ( is_page() ? ' entry--page' : '' ) ); ?>>
        <header class="entry__head">
          <?php if ( is_single() ) : $rubor_cat = get_the_category(); ?>
            <p class="eyebrow"><?php echo esc_html( ( $rubor_cat ? $rubor_cat[0]->name . ' · ' : '' ) . get_the_date() ); ?></p>
          <?php endif; ?>
          <h1 class="section-title"><?php the_title(); ?></h1>
          <?php if ( is_single() && has_excerpt() ) : ?><p class="entry__lede"><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?>
        </header>
        <?php if ( is_single() && has_post_thumbnail() ) : ?><figure class="entry__img"><?php the_post_thumbnail( 'full' ); ?></figure><?php endif; ?>
        <div class="entry__content"><?php the_content(); ?></div>
        <?php if ( is_single() ) : ?>
          <footer class="entry__foot">
            <?php the_tags( '<p class="entry__tags">', '', '</p>' ); ?>
            <nav class="entry__nav">
              <?php previous_post_link( '<span>%link</span>', '← %title' ); ?>
              <?php next_post_link( '<span>%link</span>', '%title →' ); ?>
            </nav>
          </footer>
        <?php endif; ?>
      </article>
    <?php endwhile; ?>

  <?php else : ?>
    <header class="section-head">
      <p class="eyebrow">Diario Rubor</p>
      <h1 class="section-title">
        <?php
        if ( is_category() || is_tag() ) {
          echo esc_html( single_term_title( '', false ) );
        } elseif ( is_search() ) {
          echo esc_html( 'Resultados para "' . get_search_query() . '"' );
        } else {
          echo 'Notas desde <em>el tocador.</em>';
        }
        ?>
      </h1>
      <?php
      $rubor_cats = get_categories( array( 'hide_empty' => true ) );
      if ( $rubor_cats ) :
        $rubor_blog = get_option( 'page_for_posts' ) ? get_permalink( get_option( 'page_for_posts' ) ) : home_url( '/' );
        ?>
        <nav class="filters filters--links" aria-label="Categorías del Diario">
          <a href="<?php echo esc_url( $rubor_blog ); ?>"<?php echo is_home() ? ' aria-current="page"' : ''; ?>>Todas</a>
          <?php foreach ( $rubor_cats as $c ) : ?>
            <a href="<?php echo esc_url( get_category_link( $c ) ); ?>"<?php echo is_category( $c->term_id ) ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $c->name ); ?></a>
          <?php endforeach; ?>
        </nav>
      <?php endif; ?>
    </header>

    <?php if ( have_posts() ) : ?>
      <div class="journal__grid">
        <?php while ( have_posts() ) : the_post(); get_template_part( 'parts/post-card' ); endwhile; ?>
      </div>
      <div class="page-pager"><?php the_posts_pagination( array( 'prev_text' => '←', 'next_text' => '→' ) ); ?></div>
    <?php else : ?>
      <p class="section-head">Aquí no hay nada todavía.</p>
    <?php endif; ?>
  <?php endif; ?>
</main>
<?php
get_footer();
